var xpathExpression = "/html/body/div[1]/div/div/div[2]/main/div/div/div/div/div/div[3]/div/div/div/div/div[5]/div[2]/a";

var link = document.evaluate(xpathExpression, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

if(link) {
  link.click();
} else {
  console.log("Link not found containing 'followers'");
}


funtion ClickButton() {
  var xpath = `/html/body/div[1]/div/div/div[2]/main/div/div/div/div/div/section/div/div/div[${i}]/div/div/div/div/div[2]/div[1]/div[2]/div/div` 
  var button = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  for (i = 1 ; i < 5 ; i ++ ) {
    button.click();
  }

}
