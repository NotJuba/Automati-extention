let isRunning = false; // Initially, the content script is not running




function refreshActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs.length > 0) {
      chrome.tabs.reload(tabs[0].id);
    }
  });
}


function getTabId(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (tabs && tabs.length > 0) {
      const tabId = tabs[0].id;
      callback(tabId);
    } else {
      console.error("Unable to get current tab.");
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.text === "Start") {
    getTabId((tabId) => {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['1.js']
      });
      isRunning = true;
    });
  } else if (msg.text === "Stop") {
      console.log("youre's stying to stop  it aren't you");
      refreshActiveTab();
    isRunning = false;
  }
});

