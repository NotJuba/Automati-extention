const Xpharase  = "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[2]" 
const Xsearch_bar = "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/textarea"

const phrase = document.evaluate(Xpharase, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
const search_bar = document.evaluate(Xsearch_bar, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

const sentence = phrase.value;
const firstWord = sentence.match(/\b\w+\b/)[0]; 






search_bar.value = `${firstWord} done by simo`;








