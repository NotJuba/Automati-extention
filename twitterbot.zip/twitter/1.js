var linkXPath = "/html/body/div[1]/div/div/div[2]/main/div/div/div/div/div/div[3]/div/div/div/div/div[5]/div[2]/a";

var link = document.evaluate(linkXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

if (link) {
  link.click();
  setTimeout(ClickButton, 3000); // Wait for 3 seconds after clicking the link
} else {
  console.log("Link not found containing 'followers'");
}

function ClickButton() {
  var i = 1;
  var interval = setInterval(function() {
    var buttonXPath = `/html/body/div[1]/div/div/div[2]/main/div/div/div/div/div/section/div/div/div[${i}]/div/div/div/div/div[2]/div[1]/div[2]/div/div`;
    var button = document.evaluate(buttonXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

    if (button) {
      button.click();
      i++;
    } else {
      console.log("Button not found");
      clearInterval(interval);
    }

    if (i > 20) {
      clearInterval(interval);
    }
  }, 1000); // Click every 1 second
}

