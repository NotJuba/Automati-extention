//var linkXPath = "/html/body/div[3]/div/div[2]/div/div/div/aside[1]/div/div[1]/div/div[3]/h6/a";
//var link = document.evaluate(linkXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

/*
if (link) {
  link.click();
} else {
  console.log("Link not found containing 'followers'");
}
*/


function ClickButton() {
  console.log("hey chabab")
  var i = 1;
  var interval = setInterval(function() {
    var buttonXPath = `/html/body/div[3]/div/div[2]/div/main/div/div/div[2]/div/div[${i}]/div/div/div/div[2]/div/div/span[1]/button`

    var button = document.evaluate(buttonXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

    if (button) {
      button.click();
      i++;
      console.log("it works ")
    } else {
      console.log("Button not found");
      i++;
      //clearInterval(interval);
    }

    if (i > 200) {
      clearInterval(interval);
    }

  }, 500); // Click every 1 second
}



setTimeout(ClickButton, 100); // Wait for 3 seconds after clicking the link
