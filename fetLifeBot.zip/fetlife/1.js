function ClickButton() {
  console.log("hey chabab")
  var i = 1;
  var interval = setInterval(function() {
    var buttonXPath = `/html/body/div[3]/div/div[2]/div/main/div/div/div[2]/div/div[${i}]/div/div/div/div[2]/div/div/span[1]/button`

    var button = document.evaluate(buttonXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

    if (button && button.innerText === "Follow") {
      button.click();
      i++;
      console.log("it works ")
    } else if (button && button.innerText !== "Follow") {
      console.log("Button found, but text is not 'Follow'");
      i++;
    } else {
      console.log("Button not found");
      i++;
    }

    if (i > 200) {
      clearInterval(interval);
    }

  }, 500); // Click every 0.5 seconds
}

setTimeout(ClickButton, 100); // Wait for 0.1 seconds after clicking the link

